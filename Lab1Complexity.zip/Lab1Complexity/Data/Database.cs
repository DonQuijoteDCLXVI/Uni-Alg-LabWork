using Lab1.Core;
using Microsoft.Data.Sqlite;

namespace Lab1.Data;

/// <summary>
/// SQLite-хранилище.
///  measurements       — сырые замеры (КЭШ): уникальность (algorithm, n, m, run_no)
///  experiments        — история экспериментов (параметры + дата)
///  experiment_points  — усреднённые точки каждого эксперимента (для сравнения графиков)
/// </summary>
public sealed class Database
{
    private readonly string _cs;

    public Database(string path)
    {
        _cs = new SqliteConnectionStringBuilder { DataSource = path, Mode = SqliteOpenMode.ReadWriteCreate }.ToString();
        Init();
    }

    private SqliteConnection Open()
    {
        var c = new SqliteConnection(_cs);
        c.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "PRAGMA foreign_keys=ON;";
        cmd.ExecuteNonQuery();
        return c;
    }

    private void Init()
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS measurements(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    algorithm   TEXT    NOT NULL,
    n           INTEGER NOT NULL,
    m           INTEGER NOT NULL DEFAULT 0,
    run_no      INTEGER NOT NULL,
    time_sec    REAL    NOT NULL,
    steps       INTEGER,
    measured_at TEXT    NOT NULL,
    UNIQUE(algorithm, n, m, run_no)
);
CREATE INDEX IF NOT EXISTS ix_meas_alg ON measurements(algorithm);

CREATE TABLE IF NOT EXISTS experiments(
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    algorithm     TEXT    NOT NULL,
    created_at    TEXT    NOT NULL,
    n_max         INTEGER NOT NULL,
    m_max         INTEGER NOT NULL,
    step          INTEGER NOT NULL,
    runs          INTEGER NOT NULL,
    forced        INTEGER NOT NULL,
    cached_points INTEGER NOT NULL,
    total_points  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS experiment_points(
    experiment_id INTEGER NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
    n             INTEGER NOT NULL,
    m             INTEGER NOT NULL DEFAULT 0,
    avg_time      REAL    NOT NULL,
    avg_steps     REAL    NOT NULL,
    PRIMARY KEY(experiment_id, n, m)
);";
        cmd.ExecuteNonQuery();
    }

    // ---------- КЭШ ----------

    public Dictionary<(int, int), List<Measurement>> LoadCache(string alg)
    {
        var d = new Dictionary<(int, int), List<Measurement>>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT n, m, run_no, time_sec, steps FROM measurements WHERE algorithm=$a ORDER BY n, m, run_no";
        cmd.Parameters.AddWithValue("$a", alg);
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            var key = (r.GetInt32(0), r.GetInt32(1));
            if (!d.TryGetValue(key, out var list)) d[key] = list = new List<Measurement>();
            list.Add(new Measurement(key.Item1, key.Item2, r.GetInt32(2), r.GetDouble(3),
                r.IsDBNull(4) ? null : r.GetInt64(4)));
        }
        return d;
    }

    public void SaveMeasurements(string alg, IEnumerable<Measurement> items)
    {
        using var c = Open();
        using var tx = c.BeginTransaction();
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = @"INSERT OR REPLACE INTO measurements(algorithm, n, m, run_no, time_sec, steps, measured_at)
                            VALUES($a, $n, $m, $r, $t, $s, $d)";
        var pA = cmd.Parameters.Add("$a", SqliteType.Text);
        var pN = cmd.Parameters.Add("$n", SqliteType.Integer);
        var pM = cmd.Parameters.Add("$m", SqliteType.Integer);
        var pR = cmd.Parameters.Add("$r", SqliteType.Integer);
        var pT = cmd.Parameters.Add("$t", SqliteType.Real);
        var pS = cmd.Parameters.Add("$s", SqliteType.Integer);
        var pD = cmd.Parameters.Add("$d", SqliteType.Text);
        string now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        foreach (var it in items)
        {
            pA.Value = alg; pN.Value = it.N; pM.Value = it.M; pR.Value = it.Run; pT.Value = it.Time;
            pS.Value = it.Steps.HasValue ? it.Steps.Value : DBNull.Value;
            pD.Value = now;
            cmd.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public int CountMeasurements(string alg)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM measurements WHERE algorithm=$a";
        cmd.Parameters.AddWithValue("$a", alg);
        return Convert.ToInt32(cmd.ExecuteScalar());
    }

    /// <summary>Очистка кэша (сырых замеров). История экспериментов не затрагивается.</summary>
    public int ClearCache(string alg = null)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        if (alg == null) cmd.CommandText = "DELETE FROM measurements";
        else
        {
            cmd.CommandText = "DELETE FROM measurements WHERE algorithm=$a";
            cmd.Parameters.AddWithValue("$a", alg);
        }
        return cmd.ExecuteNonQuery();
    }

    // ---------- ИСТОРИЯ ----------

    public long CreateExperiment(string alg, ExperimentParams p, int cachedPoints, int totalPoints)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = @"INSERT INTO experiments(algorithm, created_at, n_max, m_max, step, runs, forced, cached_points, total_points)
                            VALUES($a, $d, $n, $m, $s, $r, $f, $c, $t); SELECT last_insert_rowid();";
        cmd.Parameters.AddWithValue("$a", alg);
        cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
        cmd.Parameters.AddWithValue("$n", p.NMax);
        cmd.Parameters.AddWithValue("$m", p.MMax);
        cmd.Parameters.AddWithValue("$s", p.Step);
        cmd.Parameters.AddWithValue("$r", p.Runs);
        cmd.Parameters.AddWithValue("$f", p.Force ? 1 : 0);
        cmd.Parameters.AddWithValue("$c", cachedPoints);
        cmd.Parameters.AddWithValue("$t", totalPoints);
        return Convert.ToInt64(cmd.ExecuteScalar());
    }

    public void SaveExperimentPoints(long expId, IEnumerable<DataPoint> pts)
    {
        using var c = Open();
        using var tx = c.BeginTransaction();
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = "INSERT OR REPLACE INTO experiment_points(experiment_id, n, m, avg_time, avg_steps) VALUES($e,$n,$m,$t,$s)";
        var pE = cmd.Parameters.Add("$e", SqliteType.Integer);
        var pN = cmd.Parameters.Add("$n", SqliteType.Integer);
        var pM = cmd.Parameters.Add("$m", SqliteType.Integer);
        var pT = cmd.Parameters.Add("$t", SqliteType.Real);
        var pS = cmd.Parameters.Add("$s", SqliteType.Real);
        foreach (var p in pts)
        {
            pE.Value = expId; pN.Value = p.N; pM.Value = p.M; pT.Value = p.Time; pS.Value = p.Steps;
            cmd.ExecuteNonQuery();
        }
        tx.Commit();
    }

    public List<ExperimentInfo> ListExperiments()
    {
        var list = new List<ExperimentInfo>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = @"SELECT id, algorithm, created_at, n_max, m_max, step, runs, forced, cached_points, total_points
                            FROM experiments ORDER BY id DESC";
        using var r = cmd.ExecuteReader();
        while (r.Read())
        {
            list.Add(new ExperimentInfo(r.GetInt64(0), r.GetString(1),
                DateTime.Parse(r.GetString(2), System.Globalization.CultureInfo.InvariantCulture),
                r.GetInt32(3), r.GetInt32(4), r.GetInt32(5), r.GetInt32(6), r.GetInt32(7) != 0,
                r.GetInt32(8), r.GetInt32(9)));
        }
        return list;
    }

    public List<DataPoint> LoadExperimentPoints(long expId)
    {
        var list = new List<DataPoint>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT n, m, avg_time, avg_steps FROM experiment_points WHERE experiment_id=$e ORDER BY n, m";
        cmd.Parameters.AddWithValue("$e", expId);
        using var r = cmd.ExecuteReader();
        while (r.Read())
            list.Add(new DataPoint(r.GetInt32(0), r.GetInt32(1), r.GetDouble(2), r.GetDouble(3)));
        return list;
    }

    public void DeleteExperiment(long expId)
    {
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "DELETE FROM experiments WHERE id=$e";
        cmd.Parameters.AddWithValue("$e", expId);
        cmd.ExecuteNonQuery();
    }
}
