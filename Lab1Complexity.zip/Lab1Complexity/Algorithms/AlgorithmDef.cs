using Lab1.Core;

namespace Lab1.Algorithms;

/// <summary>
/// Описание исследуемого алгоритма.
/// Prepare(n, m) готовит входные данные (НЕ замеряется) и возвращает действие,
/// которое выполняет сам алгоритм (замеряется) и возвращает число шагов (0, если не считается).
/// </summary>
public sealed class AlgorithmDef
{
    public string Key { get; init; } = "";          // стабильный ключ для БД
    public string Name { get; init; } = "";
    public string Part { get; init; } = "";
    public string Description { get; init; } = "";
    public string Application { get; init; } = "";
    public string BigO { get; init; } = "";
    public string CodeRef { get; init; } = "";      // где искать код (для отчёта)
    public Model Model { get; init; }               // теоретическая модель C·f(n)
    public Metric Metric { get; init; } = Metric.Time;
    public bool TwoDim { get; init; }               // true — зависимость от (n, m), 3D-график
    public int DefaultNMax { get; init; } = 1000;
    public int DefaultMMax { get; init; }
    public int DefaultStep { get; init; } = 10;
    public int MaxN { get; init; } = 50_000_000;    // защита от переполнения памяти / стека
    public Func<int, int, Func<long>> Prepare { get; init; } = (_, _) => () => 0;

    public override string ToString() => $"[{Part}] {Name}";
}
