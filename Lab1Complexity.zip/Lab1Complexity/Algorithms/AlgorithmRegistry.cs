using Lab1.Core;

namespace Lab1.Algorithms;

/// <summary>"Приёмник" результата: не даёт JIT-компилятору выкинуть вычисления как неиспользуемые.</summary>
public static class Sink { public static double Value; }

public static class AlgorithmRegistry
{
    public static readonly IReadOnlyList<AlgorithmDef> All = Build();

    public static AlgorithmDef ByKey(string key) => All.First(a => a.Key == key);

    private static double[] Vec(int n, double lo = 0, double hi = 1000)
    {
        var v = new double[n];
        var r = Random.Shared;
        for (int i = 0; i < n; i++) v[i] = lo + r.NextDouble() * (hi - lo);
        return v;
    }

    private static List<AlgorithmDef> Build() => new()
    {
        // ================= ЧАСТЬ I. ВЕКТОРЫ =================
        new AlgorithmDef
        {
            Key = "vec_const", Part = "I", Name = "1. Постоянная функция f(v)=1",
            Description = "Возвращает константу, не обращаясь к элементам вектора. Время не зависит от n.",
            Application = "Доступ по индексу, чтение поля, проверка флага — базовые O(1)-операции (хеш-таблицы в среднем, указатели).",
            BigO = "Best/Avg/Worst: O(1)", CodeRef = "AlgorithmRegistry.cs → vec_const",
            Model = Model.Const, DefaultNMax = 1_000_000, DefaultStep = 20_000,
            Prepare = (n, _) => { var v = Vec(n); return () => { Sink.Value = 1; return 0; }; }
        },
        new AlgorithmDef
        {
            Key = "vec_sum", Part = "I", Name = "2. Сумма элементов",
            Description = "Один проход по вектору с накоплением суммы: n сложений.",
            Application = "Агрегации в аналитике, нормировка, скалярные произведения, контрольные суммы.",
            BigO = "Best/Avg/Worst: O(n)", CodeRef = "AlgorithmRegistry.cs → vec_sum",
            Model = Model.Linear, DefaultNMax = 10_000_000, DefaultStep = 200_000,
            Prepare = (n, _) =>
            {
                var v = Vec(n);
                return () => { double s = 0; for (int i = 0; i < v.Length; i++) s += v[i]; Sink.Value = s; return 0; };
            }
        },
        new AlgorithmDef
        {
            Key = "vec_prod", Part = "I", Name = "3. Произведение элементов",
            Description = "Один проход с накоплением произведения: n умножений (элементы взяты около 1, чтобы избежать денормализованных чисел).",
            Application = "Вычисление правдоподобия/вероятностей, факториалоподобные накопления, масштабные коэффициенты.",
            BigO = "Best/Avg/Worst: O(n)", CodeRef = "AlgorithmRegistry.cs → vec_prod",
            Model = Model.Linear, DefaultNMax = 10_000_000, DefaultStep = 200_000,
            Prepare = (n, _) =>
            {
                var v = Vec(n, 0.999, 1.001);
                return () => { double p = 1; for (int i = 0; i < v.Length; i++) p *= v[i]; Sink.Value = p; return 0; };
            }
        },
        new AlgorithmDef
        {
            Key = "poly_naive", Part = "I", Name = "4а. Многочлен: прямое вычисление",
            Description = "Для каждого члена v_k·x^(k-1) степень считается заново циклом умножений: 0+1+…+(n-1) = n(n-1)/2 умножений.",
            Application = "Учебный пример «как не надо»; показывает цену повторных вычислений одних и тех же степеней.",
            BigO = "Best/Avg/Worst: O(n²)", CodeRef = "AlgorithmRegistry.cs → poly_naive",
            Model = Model.Quadratic, DefaultNMax = 20_000, DefaultStep = 500, MaxN = 200_000,
            Prepare = (n, _) =>
            {
                var v = Vec(n, 0, 1);
                const double x = 1.5;
                return () =>
                {
                    double s = 0;
                    for (int k = 0; k < v.Length; k++)
                    {
                        double pw = 1;
                        for (int j = 0; j < k; j++) pw *= x;   // x^(k) заново для каждого члена
                        s += v[k] * pw;
                    }
                    Sink.Value = s; return 0;
                };
            }
        },
        new AlgorithmDef
        {
            Key = "poly_horner", Part = "I", Name = "4б. Многочлен: схема Горнера",
            Description = "P(x)=v1+x(v2+x(v3+…)): один проход, на каждом шаге одно умножение и одно сложение.",
            Application = "Стандарт вычисления многочленов (математические библиотеки, CRC, хеширование, аппроксимация функций).",
            BigO = "Best/Avg/Worst: O(n)", CodeRef = "AlgorithmRegistry.cs → poly_horner",
            Model = Model.Linear, DefaultNMax = 10_000_000, DefaultStep = 200_000,
            Prepare = (n, _) =>
            {
                var v = Vec(n, 0, 1);
                const double x = 1.5;
                return () => { double s = 0; for (int k = v.Length - 1; k >= 0; k--) s = s * x + v[k]; Sink.Value = s; return 0; };
            }
        },
        new AlgorithmDef
        {
            Key = "bubble", Part = "I", Name = "5. Сортировка пузырьком",
            Description = "Многократные проходы по массиву со сравнением соседних элементов и обменом; с флагом раннего выхода.",
            Application = "Почти не используется в продакшене; полезна для обучения и для очень маленьких/почти отсортированных массивов.",
            BigO = "Best: O(n) (с флагом) · Avg: O(n²) · Worst: O(n²)", CodeRef = "AlgorithmRegistry.cs → BubbleSort",
            Model = Model.Quadratic, DefaultNMax = 10_000, DefaultStep = 200, MaxN = 100_000,
            Prepare = (n, _) => { var v = Vec(n); return () => { BubbleSort(v); Sink.Value = v[0]; return 0; }; }
        },
        new AlgorithmDef
        {
            Key = "quick", Part = "I", Name = "6. Быстрая сортировка (Quick sort)",
            Description = "Разделяй и властвуй: выбор опорного элемента, разбиение (Хоар), рекурсия по меньшей части + цикл по большей.",
            Application = "Основа многих библиотечных сортировок (introsort), хорошая локальность кэша, сортировка в памяти.",
            BigO = "Best/Avg: O(n log n) · Worst: O(n²) (редко при выборе среднего опорного)", CodeRef = "AlgorithmRegistry.cs → QuickSort",
            Model = Model.NLogN, DefaultNMax = 2_000_000, DefaultStep = 40_000,
            Prepare = (n, _) => { var v = Vec(n); return () => { QuickSort(v, 0, v.Length - 1); Sink.Value = v[0]; return 0; }; }
        },
        new AlgorithmDef
        {
            Key = "array_sort", Part = "I", Name = "7. Стандартная сортировка языка (Array.Sort)",
            Description = "Встроенная гибридная сортировка .NET — introsort (quick sort + heap sort + insertion sort). Timsort в C# не является стандартной реализацией (он в Python/Java).",
            Application = "Повседневная сортировка в .NET-приложениях: Array.Sort, List<T>.Sort.",
            BigO = "Best/Avg/Worst: O(n log n)", CodeRef = "AlgorithmRegistry.cs → array_sort",
            Model = Model.NLogN, DefaultNMax = 2_000_000, DefaultStep = 40_000,
            Prepare = (n, _) => { var v = Vec(n); return () => { Array.Sort(v); Sink.Value = v[0]; return 0; }; }
        },

        // ================= ЧАСТЬ II. МАТРИЦЫ =================
        new AlgorithmDef
        {
            Key = "matmul", Part = "II", Name = "8. Произведение матриц (классическое)",
            Description = "C = A×B, где A — n×m, B — m×n, C — n×n. Три вложенных цикла: n·n·m умножений. При n=m это O(n³).",
            Application = "Линейная алгебра, графика, нейросети; на практике используют блочные/Штрассена/BLAS.",
            BigO = "Best/Avg/Worst: O(n²·m), при n=m — O(n³)", CodeRef = "AlgorithmRegistry.cs → matmul",
            Model = Model.N2M, TwoDim = true, DefaultNMax = 300, DefaultMMax = 300, DefaultStep = 30, MaxN = 3000,
            Prepare = (n, m) =>
            {
                var a = Mat(n, m); var b = Mat(m, n);
                var c = new double[n][];
                for (int i = 0; i < n; i++) c[i] = new double[n];
                return () =>
                {
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < n; j++)
                        {
                            double s = 0;
                            for (int k = 0; k < m; k++) s += a[i][k] * b[k][j];
                            c[i][j] = s;
                        }
                    Sink.Value = c[n - 1][n - 1]; return 0;
                };
            }
        },

        // ================= ЧАСТЬ III. ИНДИВИДУАЛЬНЫЕ (примеры — замените своими!) =================
        new AlgorithmDef
        {
            Key = "merge", Part = "III", Name = "9а. Сортировка слиянием (Merge sort)",
            Description = "Делит массив пополам, рекурсивно сортирует части и сливает их с помощью буфера.",
            Application = "Устойчивая сортировка, внешняя сортировка (файлы), сортировка связных списков, основа Timsort.",
            BigO = "Best/Avg/Worst: O(n log n), память O(n)", CodeRef = "AlgorithmRegistry.cs → MergeSort",
            Model = Model.NLogN, DefaultNMax = 2_000_000, DefaultStep = 40_000,
            Prepare = (n, _) => { var v = Vec(n); return () => { MergeSort(v); Sink.Value = v[0]; return 0; }; }
        },
        new AlgorithmDef
        {
            Key = "heap", Part = "III", Name = "9б. Пирамидальная сортировка (Heap sort)",
            Description = "Строит max-кучу на месте, затем n раз извлекает максимум в конец массива.",
            Application = "Гарантированный O(n log n) без доп. памяти; запасной режим introsort; приоритетные очереди.",
            BigO = "Best/Avg/Worst: O(n log n), память O(1)", CodeRef = "AlgorithmRegistry.cs → HeapSort",
            Model = Model.NLogN, DefaultNMax = 2_000_000, DefaultStep = 40_000,
            Prepare = (n, _) => { var v = Vec(n); return () => { HeapSort(v); Sink.Value = v[0]; return 0; }; }
        },
        new AlgorithmDef
        {
            Key = "sieve", Part = "III", Name = "9в. Решето Эратосфена",
            Description = "Находит все простые ≤ n: вычёркивает кратные каждого найденного простого, начиная с p².",
            Application = "Теория чисел, генерация простых для криптографии, олимпиадное программирование.",
            BigO = "Best/Avg/Worst: O(n log log n), память O(n)", CodeRef = "AlgorithmRegistry.cs → sieve",
            Model = Model.NLogLogN, DefaultNMax = 20_000_000, DefaultStep = 400_000, MaxN = 200_000_000,
            Prepare = (n, _) => () =>
            {
                var comp = new bool[n + 1];
                for (long i = 2; i * i <= n; i++)
                    if (!comp[i])
                        for (long j = i * i; j <= n; j += i) comp[j] = true;
                long cnt = 0;
                for (int i = 2; i <= n; i++) if (!comp[i]) cnt++;
                Sink.Value = cnt; return 0;
            }
        },

        // ================= ЧАСТЬ IV. ВОЗВЕДЕНИЕ В СТЕПЕНЬ (считаем ШАГИ) =================
        new AlgorithmDef
        {
            Key = "pow_naive", Part = "IV", Name = "10. Степень: простой итеративный",
            Description = "Цикл из n умножений: res ← res·x (счётчик увеличивается на каждом умножении).",
            Application = "Малые показатели степени; базовый вариант для сравнения.",
            BigO = "По шагам: O(n)", CodeRef = "AlgorithmRegistry.cs → PowNaive",
            Model = Model.Linear, Metric = Metric.Steps, DefaultNMax = 1000, DefaultStep = 1, MaxN = 100_000_000,
            Prepare = (n, _) => () => { long st = 0; Sink.Value = PowNaive(1.0001, n, ref st); return st; }
        },
        new AlgorithmDef
        {
            Key = "pow_rec", Part = "IV", Name = "11. Степень: рекурсивный x·x^(n-1)",
            Description = "x^n = x·x^(n-1), база x^0 = 1: n рекурсивных вызовов и n умножений. Глубина рекурсии n.",
            Application = "Учебная иллюстрация рекурсии; в реальном коде не годится из-за глубины стека.",
            BigO = "По шагам: O(n), стек O(n)", CodeRef = "AlgorithmRegistry.cs → PowRec",
            Model = Model.Linear, Metric = Metric.Steps, DefaultNMax = 1000, DefaultStep = 1, MaxN = 5000,
            Prepare = (n, _) => () => { long st = 0; Sink.Value = PowRec(1.0001, n, ref st); return st; }
        },
        new AlgorithmDef
        {
            Key = "pow_fast", Part = "IV", Name = "12. Степень: быстрый (бинарный)",
            Description = "x^n = (x^(n/2))² для чётных n и x·(x^(n/2))² для нечётных: ≈ log₂n возведений в квадрат + ≤ log₂n умножений на x.",
            Application = "Криптография (RSA, Диффи–Хеллман: модульное возведение), длинная арифметика, возведение матриц в степень.",
            BigO = "По шагам: O(log n)", CodeRef = "AlgorithmRegistry.cs → PowFast",
            Model = Model.Log, Metric = Metric.Steps, DefaultNMax = 1000, DefaultStep = 1, MaxN = 2_000_000_000,
            Prepare = (n, _) => () => { long st = 0; Sink.Value = PowFast(1.0001, n, ref st); return st; }
        },
    };

    // ---------------- вспомогательные реализации ----------------

    private static double[][] Mat(int rows, int cols)
    {
        var r = Random.Shared;
        var a = new double[rows][];
        for (int i = 0; i < rows; i++)
        {
            a[i] = new double[cols];
            for (int j = 0; j < cols; j++) a[i][j] = r.NextDouble() * 10;
        }
        return a;
    }

    public static void BubbleSort(double[] a)
    {
        for (int pass = 0; pass < a.Length - 1; pass++)
        {
            bool swapped = false;
            for (int j = 0; j < a.Length - 1 - pass; j++)
                if (a[j] > a[j + 1]) { (a[j], a[j + 1]) = (a[j + 1], a[j]); swapped = true; }
            if (!swapped) break;
        }
    }

    public static void QuickSort(double[] a, int lo, int hi)
    {
        while (lo < hi)
        {
            int i = lo, j = hi;
            double p = a[lo + (hi - lo) / 2];
            while (i <= j)
            {
                while (a[i] < p) i++;
                while (a[j] > p) j--;
                if (i <= j) { (a[i], a[j]) = (a[j], a[i]); i++; j--; }
            }
            // рекурсия по меньшей части, цикл по большей => глубина стека O(log n)
            if (j - lo < hi - i) { QuickSort(a, lo, j); lo = i; }
            else { QuickSort(a, i, hi); hi = j; }
        }
    }

    public static void MergeSort(double[] a)
    {
        var tmp = new double[a.Length];
        MergeRec(a, tmp, 0, a.Length - 1);
    }

    private static void MergeRec(double[] a, double[] t, int lo, int hi)
    {
        if (lo >= hi) return;
        int mid = lo + (hi - lo) / 2;
        MergeRec(a, t, lo, mid);
        MergeRec(a, t, mid + 1, hi);
        int i = lo, j = mid + 1, k = lo;
        while (i <= mid && j <= hi) t[k++] = a[i] <= a[j] ? a[i++] : a[j++];
        while (i <= mid) t[k++] = a[i++];
        while (j <= hi) t[k++] = a[j++];
        Array.Copy(t, lo, a, lo, hi - lo + 1);
    }

    public static void HeapSort(double[] a)
    {
        int n = a.Length;
        for (int i = n / 2 - 1; i >= 0; i--) Sift(a, i, n);
        for (int end = n - 1; end > 0; end--)
        {
            (a[0], a[end]) = (a[end], a[0]);
            Sift(a, 0, end);
        }
    }

    private static void Sift(double[] a, int i, int n)
    {
        while (true)
        {
            int l = 2 * i + 1;
            if (l >= n) return;
            int r = l + 1;
            int big = (r < n && a[r] > a[l]) ? r : l;
            if (a[big] <= a[i]) return;
            (a[i], a[big]) = (a[big], a[i]);
            i = big;
        }
    }

    // ---- возведение в степень со счётчиком умножений ----

    public static double PowNaive(double x, int n, ref long steps)
    {
        double res = 1;
        for (int i = 0; i < n; i++) { res *= x; steps++; }
        return res;
    }

    public static double PowRec(double x, int n, ref long steps)
    {
        if (n == 0) return 1;
        steps++;                                  // одно умножение на этом уровне
        return x * PowRec(x, n - 1, ref steps);
    }

    public static double PowFast(double x, int n, ref long steps)
    {
        if (n == 0) return 1;
        if (n == 1) return x;
        double half = PowFast(x, n / 2, ref steps);
        steps++;                                  // возведение в квадрат
        double sq = half * half;
        if ((n & 1) == 1) { steps++; sq *= x; }   // доп. умножение для нечётного n
        return sq;
    }
}
