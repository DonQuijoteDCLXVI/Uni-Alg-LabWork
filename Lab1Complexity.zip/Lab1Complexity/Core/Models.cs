namespace Lab1.Core;

/// <summary>Что откладывается по оси Y: время (с) или число элементарных операций.</summary>
public enum Metric { Time, Steps }

/// <summary>Теоретические функции сложности f(n), по которым строится аппроксимация C·f(n).</summary>
public enum Model { Const, Log, Linear, NLogLogN, NLogN, Quadratic, Cubic, N2M }

/// <summary>Одно "сырое" измерение (один запуск). Хранится в таблице measurements.</summary>
public sealed record Measurement(int N, int M, int Run, double Time, long? Steps);

/// <summary>Усреднённая точка эксперимента (по всем запускам для данного n [и m]).</summary>
public sealed record DataPoint(int N, int M, double Time, double Steps)
{
    public double Value(Metric metric) => metric == Metric.Time ? Time : Steps;
}

/// <summary>Запись об эксперименте в истории.</summary>
public sealed record ExperimentInfo(long Id, string Algorithm, DateTime CreatedAt, int NMax, int MMax,
    int Step, int Runs, bool Forced, int CachedPoints, int TotalPoints);

/// <summary>Параметры, которые задаёт пользователь в GUI.</summary>
public sealed record ExperimentParams(int NMax, int MMax, int Step, int Runs, bool Force);

public sealed class RunResult
{
    public List<DataPoint> Points { get; init; } = new();
    public int CachedPoints { get; init; }
    public int TotalPoints { get; init; }
    public int NewMeasurements { get; init; }
    public long ExperimentId { get; init; }
    public bool Cancelled { get; init; }
    public double ElapsedSec { get; init; }
}
