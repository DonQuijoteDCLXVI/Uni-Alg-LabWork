namespace Lab1.Core;

public sealed record FitResult(Model Model, double C, double Mse);

public static class ModelFn
{
    /// <summary>Значение теоретической функции f(n) (для N2M — f(n,m) = n²·m).</summary>
    public static double F(Model model, double n, double m = 0)
    {
        double l2 = Math.Log2(Math.Max(n, 2));
        return model switch
        {
            Model.Const => 1.0,
            Model.Log => l2,
            Model.Linear => n,
            Model.NLogLogN => n * Math.Log(Math.Log(Math.Max(n, 3))),
            Model.NLogN => n * l2,
            Model.Quadratic => n * n,
            Model.Cubic => n * n * n,
            Model.N2M => n * n * m,
            _ => n
        };
    }

    public static string Title(Model model) => model switch
    {
        Model.Const => "C·1",
        Model.Log => "C·log₂ n",
        Model.Linear => "C·n",
        Model.NLogLogN => "C·n·ln ln n",
        Model.NLogN => "C·n·log₂ n",
        Model.Quadratic => "C·n²",
        Model.Cubic => "C·n³",
        Model.N2M => "C·n²·m",
        _ => model.ToString()
    };

    public static IReadOnlyList<Model> Applicable(bool twoDim) => twoDim
        ? new[] { Model.N2M, Model.Quadratic, Model.Linear, Model.Const }
        : new[] { Model.Const, Model.Log, Model.Linear, Model.NLogLogN, Model.NLogN, Model.Quadratic, Model.Cubic };
}

public static class Approximation
{
    /// <summary>
    /// Метод наименьших квадратов для модели T = C·f(n) (подгоняется один параметр C).
    /// Минимизируем Σ(T_i − C·f_i)²  =>  C = Σ(T_i·f_i) / Σ(f_i²).
    /// MSE = (1/k)·Σ(T_i − C·f_i)².
    /// </summary>
    public static FitResult Fit(IReadOnlyList<DataPoint> pts, Metric metric, Model model)
    {
        double sfy = 0, sff = 0;
        foreach (var p in pts)
        {
            double f = ModelFn.F(model, p.N, p.M);
            double y = p.Value(metric);
            sfy += f * y;
            sff += f * f;
        }
        double c = sff > 0 ? sfy / sff : 0;

        double mse = 0;
        foreach (var p in pts)
        {
            double d = p.Value(metric) - c * ModelFn.F(model, p.N, p.M);
            mse += d * d;
        }
        mse = pts.Count > 0 ? mse / pts.Count : 0;
        return new FitResult(model, c, mse);
    }

    /// <summary>Подгоняет все модели и возвращает список, отсортированный по возрастанию MSE.</summary>
    public static List<FitResult> FitAll(IReadOnlyList<DataPoint> pts, Metric metric, IEnumerable<Model> models)
        => models.Select(m => Fit(pts, metric, m)).OrderBy(f => f.Mse).ToList();
}
