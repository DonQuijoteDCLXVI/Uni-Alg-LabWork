using System.Diagnostics;
using Lab1.Algorithms;
using Lab1.Data;

namespace Lab1.Core;

/// <summary>
/// Проводит эксперимент: для каждой точки сетки (n[,m]) делает заданное число независимых запусков,
/// использует кэш из БД и сохраняет новые измерения.
/// </summary>
public static class ExperimentRunner
{
    public static Task<RunResult> RunAsync(AlgorithmDef alg, ExperimentParams p, Database db,
        IProgress<(int Done, int Total)> progress, CancellationToken ct)
        => Task.Run(() => Run(alg, p, db, progress, ct));

    public static RunResult Run(AlgorithmDef alg, ExperimentParams p, Database db,
        IProgress<(int Done, int Total)> progress, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        var ns = Grid(p.NMax, p.Step);
        var ms = alg.TwoDim ? Grid(p.MMax, p.Step) : new List<int> { 0 };
        var grid = new List<(int n, int m)>();
        foreach (var n in ns) foreach (var m in ms) grid.Add((n, m));

        // КЭШ: при обычном запуске подгружаем из БД всё, что уже измерено для этого алгоритма.
        // При принудительном пересчёте кэш игнорируется, а новые значения перезапишут старые (INSERT OR REPLACE).
        var cache = p.Force
            ? new Dictionary<(int, int), List<Measurement>>()
            : db.LoadCache(alg.Key);

        var fresh = new List<Measurement>();
        var points = new List<DataPoint>();
        int cachedPoints = 0, done = 0;
        bool cancelled = false;

        try
        {
            // Прогрев: JIT-компиляция и разогрев кэшей процессора до начала замеров.
            var w = grid[grid.Count / 10];
            for (int i = 0; i < 2; i++) alg.Prepare(w.n, w.m)();

            foreach (var (n, m) in grid)
            {
                ct.ThrowIfCancellationRequested();

                var runs = new List<Measurement>();
                if (cache.TryGetValue((n, m), out var old))
                    runs.AddRange(old.Where(x => x.Run >= 1 && x.Run <= p.Runs));

                bool measuredAny = false;
                for (int r = 1; r <= p.Runs; r++)
                {
                    if (runs.Any(x => x.Run == r)) continue;   // этот запуск уже есть в кэше
                    var meas = Measure(alg, n, m, r);
                    runs.Add(meas);
                    fresh.Add(meas);
                    measuredAny = true;
                }
                if (!measuredAny) cachedPoints++;

                points.Add(new DataPoint(n, m,
                    runs.Average(x => x.Time),
                    runs.Average(x => (double)(x.Steps ?? 0))));

                progress?.Report((++done, grid.Count));
            }
        }
        catch (OperationCanceledException)
        {
            cancelled = true;
        }
        finally
        {
            // Даже при отмене сохраняем то, что успели измерить, — это пополнит кэш.
            if (fresh.Count > 0) db.SaveMeasurements(alg.Key, fresh);
        }

        long expId = 0;
        if (!cancelled)
        {
            expId = db.CreateExperiment(alg.Key, p, cachedPoints, grid.Count);
            db.SaveExperimentPoints(expId, points);
        }

        sw.Stop();
        return new RunResult
        {
            Points = points,
            CachedPoints = cachedPoints,
            TotalPoints = grid.Count,
            NewMeasurements = fresh.Count,
            ExperimentId = expId,
            Cancelled = cancelled,
            ElapsedSec = sw.Elapsed.TotalSeconds
        };
    }

    /// <summary>Генерация входных данных (Prepare) НЕ входит во время; замеряется только действие алгоритма.</summary>
    private static Measurement Measure(AlgorithmDef a, int n, int m, int run)
    {
        var action = a.Prepare(n, m);
        long t0 = Stopwatch.GetTimestamp();
        long steps = action();
        long t1 = Stopwatch.GetTimestamp();
        double sec = (t1 - t0) / (double)Stopwatch.Frequency;
        return new Measurement(n, m, run, sec, a.Metric == Metric.Steps ? steps : null);
    }

    /// <summary>Сетка значений: 1, step, 2·step, ... ≤ max.</summary>
    public static List<int> Grid(int max, int step)
    {
        var l = new List<int> { 1 };
        for (long v = step; v <= max; v += step)
            if (v != 1) l.Add((int)v);
        return l.Distinct().ToList();
    }
}
