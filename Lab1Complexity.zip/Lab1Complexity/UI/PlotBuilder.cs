using Lab1.Algorithms;
using Lab1.Core;

namespace Lab1.UI;

/// <summary>Общая логика наполнения графиков (используется и окном, и генератором отчёта).</summary>
public static class PlotBuilder
{
    public static string YLabel(AlgorithmDef a) => a.Metric == Metric.Time ? "Время, с" : "Количество шагов (умножений)";

    public static void FillChart(ChartControl c, AlgorithmDef a, IReadOnlyList<DataPoint> pts, Model model, FitResult fit)
    {
        c.Series.Clear();
        var emp = new ChartSeries
        {
            Name = a.Metric == Metric.Time ? "Эмпирические точки (среднее время)" : "Эмпирические точки (среднее число шагов)",
            Color = Color.SteelBlue, Markers = true, Width = 1.2f
        };
        var app = new ChartSeries { Name = $"Аппроксимация {ModelFn.Title(model)}", Color = Color.OrangeRed, Width = 2.5f };
        foreach (var p in pts)
        {
            emp.Pts.Add((p.N, p.Value(a.Metric)));
            app.Pts.Add((p.N, fit.C * ModelFn.F(model, p.N)));
        }
        c.Series.Add(emp);
        c.Series.Add(app);
        c.Title = $"{a.Name} — C={fit.C:G4}, MSE={fit.Mse:E3}";
        c.XLabel = "Размерность входа n";
        c.YLabel = YLabel(a);
        c.LogY = false;
        c.Invalidate();
    }

    public static void FillSurface(Surface3DControl s, AlgorithmDef a, IReadOnlyList<DataPoint> pts, Model model, FitResult fit)
    {
        var xs = pts.Select(p => (double)p.N).Distinct().OrderBy(v => v).ToArray();
        var ys = pts.Select(p => (double)p.M).Distinct().OrderBy(v => v).ToArray();
        var emp = new double[xs.Length, ys.Length];
        var app = new double[xs.Length, ys.Length];
        var map = pts.ToDictionary(p => (p.N, p.M), p => p.Value(a.Metric));
        for (int i = 0; i < xs.Length; i++)
            for (int j = 0; j < ys.Length; j++)
            {
                int n = (int)xs[i], m = (int)ys[j];
                emp[i, j] = map.TryGetValue((n, m), out var v) ? v : 0;
                app[i, j] = fit.C * ModelFn.F(model, n, m);
            }
        s.SetData(xs, ys, emp, app, "n", "m", "t, с", $"{a.Name} — C={fit.C:G4}, MSE={fit.Mse:E3}");
    }
}
