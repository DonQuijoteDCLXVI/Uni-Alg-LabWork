using System.Diagnostics;
using System.Globalization;
using Lab1.Algorithms;
using Lab1.Core;
using Lab1.Data;

namespace Lab1.UI;

public sealed class MainForm : Form
{
    private sealed class ModelItem
    {
        public Model? Value;
        public string Title = "";
        public override string ToString() => Title;
    }

    private readonly Database _db;
    private CancellationTokenSource _cts;
    private AlgorithmDef _shownAlg;

    // --- панель параметров ---
    private readonly ComboBox _cbAlg = new() { DropDownStyle = ComboBoxStyle.DropDownList, DropDownWidth = 480 };
    private readonly ComboBox _cbModel = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox _txtInfo = new() { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Height = 210, BackColor = SystemColors.Window };
    private readonly NumericUpDown _numN = new() { Minimum = 1, Maximum = 200_000_000, Value = 1000, ThousandsSeparator = true };
    private readonly NumericUpDown _numM = new() { Minimum = 1, Maximum = 200_000_000, Value = 100, ThousandsSeparator = true };
    private readonly NumericUpDown _numStep = new() { Minimum = 1, Maximum = 1_000_000_000, Value = 10, ThousandsSeparator = true };
    private readonly NumericUpDown _numRuns = new() { Minimum = 1, Maximum = 100, Value = 5 };
    private readonly CheckBox _chkForce = new() { Text = "Принудительный пересчёт (игнорировать кэш)", AutoSize = true };
    private readonly Button _btnRun = new() { Text = "▶ Запустить", AutoSize = true };
    private readonly Button _btnCancel = new() { Text = "■ Отмена", AutoSize = true, Enabled = false };
    private readonly Button _btnClear = new() { Text = "Очистить кэш алгоритма", AutoSize = true };
    private readonly Button _btnPng = new() { Text = "Экспорт PNG", AutoSize = true };
    private readonly Button _btnReport = new() { Text = "Отчёт (Markdown)", AutoSize = true };
    private readonly ProgressBar _pb = new() { Height = 18 };
    private readonly Label _lblStatus = new() { AutoSize = true, Text = "Готово." };

    // --- результаты ---
    private readonly TabControl _tabs = new();
    private readonly ChartControl _chart = new();
    private readonly Surface3DControl _surf = new();
    private readonly Label _lblFit = new() { Height = 44, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(6, 0, 0, 0) };
    private readonly DataGridView _gridFit = new();

    // --- история ---
    private readonly ListView _lvHist = new() { View = View.Details, CheckBoxes = true, FullRowSelect = true, GridLines = true };
    private readonly ChartControl _hist = new();
    private readonly CheckBox _chkNorm = new() { Text = "Нормировать (÷ max)", AutoSize = true };
    private readonly CheckBox _chkLog = new() { Text = "Лог. шкала Y", AutoSize = true };

    private readonly TextBox _txtLog = new()
    {
        Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill,
        Font = new Font("Consolas", 9f)
    };

    private static readonly Color[] Palette =
    {
        Color.SteelBlue, Color.OrangeRed, Color.SeaGreen, Color.MediumPurple, Color.Goldenrod,
        Color.Crimson, Color.Teal, Color.SaddleBrown, Color.DeepPink, Color.DimGray
    };

    public MainForm()
    {
        Text = "Лабораторная работа №1 — эмпирический анализ временной сложности алгоритмов";
        Width = 1400; Height = 880;
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9f);

        _db = new Database(Path.Combine(AppContext.BaseDirectory, "experiments.db"));

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 360));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.Controls.Add(BuildLeft(), 0, 0);
        root.Controls.Add(BuildRight(), 1, 0);
        Controls.Add(root);

        foreach (var a in AlgorithmRegistry.All) _cbAlg.Items.Add(a);
        _cbModel.Items.Add(new ModelItem { Value = null, Title = "Теоретическая модель алгоритма" });
        foreach (Model m in Enum.GetValues(typeof(Model)))
            _cbModel.Items.Add(new ModelItem { Value = m, Title = ModelFn.Title(m) });
        _cbModel.SelectedIndex = 0;

        _cbAlg.SelectedIndexChanged += (_, _) => OnAlgChanged();
        _btnRun.Click += OnRun;
        _btnCancel.Click += (_, _) => _cts?.Cancel();
        _btnClear.Click += OnClearCache;
        _btnPng.Click += OnExportPng;
        _btnReport.Click += OnReport;
        FormClosing += (_, _) => _cts?.Cancel();
        _cbAlg.SelectedIndex = 0;

        Shown += (_, _) => RefreshHistory();
        Log($"БД: {Path.Combine(AppContext.BaseDirectory, "experiments.db")}");
    }

    // ===================== построение интерфейса =====================

    private Control BuildLeft()
    {
        var t = new TableLayoutPanel { Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Padding = new Padding(6) };
        t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118));
        t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        Row(t, "Алгоритм:", _cbAlg);
        Row(t, null, _txtInfo);
        Row(t, "N max:", _numN);
        Row(t, "M max (матрицы):", _numM);
        Row(t, "Шаг:", _numStep);
        Row(t, "Запусков на точку:", _numRuns);
        Row(t, "Аппроксимация:", _cbModel);
        Row(t, null, _chkForce);

        var f1 = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight };
        f1.Controls.AddRange(new Control[] { _btnRun, _btnCancel });
        Row(t, null, f1);
        Row(t, null, _pb);
        Row(t, null, _lblStatus);

        var f2 = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.TopDown };
        f2.Controls.AddRange(new Control[] { _btnClear, _btnPng, _btnReport });
        Row(t, null, f2);

        var p = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        p.Controls.Add(t);
        return p;
    }

    private static void Row(TableLayoutPanel t, string label, Control c)
    {
        int r = t.RowCount++;
        t.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        if (label == null)
        {
            t.Controls.Add(c, 0, r);
            t.SetColumnSpan(c, 2);
        }
        else
        {
            t.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(3, 6, 3, 6) }, 0, r);
            t.Controls.Add(c, 1, r);
        }
        if (c is not FlowLayoutPanel && c is not Label && c is not CheckBox && c is not Button)
            c.Dock = DockStyle.Fill;
        c.Margin = new Padding(3, 3, 3, 5);
    }

    private Control BuildRight()
    {
        _tabs.Dock = DockStyle.Fill;

        // --- вкладка «Результат» ---
        var tabRes = new TabPage("Результат");
        var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal };
        _chart.Dock = DockStyle.Fill;
        _surf.Dock = DockStyle.Fill;
        _surf.Visible = false;
        split.Panel1.Controls.Add(_chart);
        split.Panel1.Controls.Add(_surf);

        _gridFit.Dock = DockStyle.Fill;
        _gridFit.ReadOnly = true;
        _gridFit.AllowUserToAddRows = false;
        _gridFit.RowHeadersVisible = false;
        _gridFit.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        _gridFit.Columns.Add("model", "Модель T(n)");
        _gridFit.Columns.Add("c", "C");
        _gridFit.Columns.Add("mse", "MSE");
        _gridFit.Columns.Add("rank", "Лучшая по MSE");
        _gridFit.Columns.Add("sel", "Показана на графике");
        _lblFit.Dock = DockStyle.Top;
        split.Panel2.Controls.Add(_gridFit);
        split.Panel2.Controls.Add(_lblFit);
        tabRes.Controls.Add(split);

        // --- вкладка «История» ---
        var tabHist = new TabPage("История и сравнение");
        var hsplit = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Horizontal };
        _lvHist.Dock = DockStyle.Fill;
        _lvHist.Columns.Add("ID", 50);
        _lvHist.Columns.Add("Алгоритм", 260);
        _lvHist.Columns.Add("Дата", 130);
        _lvHist.Columns.Add("N max", 80);
        _lvHist.Columns.Add("M max", 60);
        _lvHist.Columns.Add("Шаг", 60);
        _lvHist.Columns.Add("Запусков", 70);
        _lvHist.Columns.Add("Точек из кэша", 100);
        _lvHist.Columns.Add("Принуд.", 60);

        var bar = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true };
        var bRefresh = new Button { Text = "Обновить", AutoSize = true };
        var bShow = new Button { Text = "Показать выбранный в «Результат»", AutoSize = true };
        var bCompare = new Button { Text = "Сравнить отмеченные", AutoSize = true };
        var bDelete = new Button { Text = "Удалить отмеченные", AutoSize = true };
        bar.Controls.AddRange(new Control[] { bRefresh, bShow, bCompare, bDelete, _chkNorm, _chkLog });
        hsplit.Panel1.Controls.Add(_lvHist);
        hsplit.Panel1.Controls.Add(bar);
        _hist.Dock = DockStyle.Fill;
        hsplit.Panel2.Controls.Add(_hist);
        tabHist.Controls.Add(hsplit);

        bRefresh.Click += (_, _) => RefreshHistory();
        bShow.Click += OnShowSelected;
        bCompare.Click += (_, _) => CompareSelected();
        bDelete.Click += OnDeleteChecked;
        _chkNorm.CheckedChanged += (_, _) => CompareSelected();
        _chkLog.CheckedChanged += (_, _) => CompareSelected();
        _lvHist.ItemChecked += (_, _) => CompareSelected();

        // --- журнал ---
        var tabLog = new TabPage("Журнал");
        tabLog.Controls.Add(_txtLog);

        _tabs.TabPages.AddRange(new[] { tabRes, tabHist, tabLog });

        Shown += (_, _) =>
        {
            try { split.SplitterDistance = (int)(split.Height * 0.72); } catch { }
            try { hsplit.SplitterDistance = (int)(hsplit.Height * 0.35); } catch { }
        };
        return _tabs;
    }

    // ===================== обработчики =====================

    private AlgorithmDef Current => (AlgorithmDef)_cbAlg.SelectedItem;

    private void OnAlgChanged()
    {
        var a = Current;
        _txtInfo.Text =
            a.Name + "\r\n\r\n" +
            "Принцип: " + a.Description + "\r\n\r\n" +
            "Применение: " + a.Application + "\r\n\r\n" +
            "Сложность: " + a.BigO + "\r\n\r\n" +
            "Метрика: " + (a.Metric == Metric.Time ? "время, с" : "число шагов (умножений)") +
            (a.TwoDim ? "\r\nГрафик: 3D, зависимость от n и m" : "");

        _numN.Maximum = a.MaxN;
        _numN.Value = Math.Min(a.DefaultNMax, a.MaxN);
        _numM.Maximum = a.MaxN;
        _numM.Value = Math.Min(Math.Max(a.DefaultMMax, 1), a.MaxN);
        _numStep.Value = Math.Max(1, a.DefaultStep);
        _numM.Enabled = a.TwoDim;
        _chart.Visible = !a.TwoDim;
        _surf.Visible = a.TwoDim;
    }

    private async void OnRun(object sender, EventArgs e)
    {
        var alg = Current;
        var p = new ExperimentParams((int)_numN.Value, (int)_numM.Value, (int)_numStep.Value, (int)_numRuns.Value, _chkForce.Checked);

        int points = ExperimentRunner.Grid(p.NMax, p.Step).Count * (alg.TwoDim ? ExperimentRunner.Grid(p.MMax, p.Step).Count : 1);
        if (points > 5000 &&
            MessageBox.Show($"Будет измерено {points} точек × {p.Runs} запусков. Продолжить?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            return;

        SetBusy(true);
        _cts = new CancellationTokenSource();
        var progress = new Progress<(int Done, int Total)>(t =>
        {
            _pb.Maximum = Math.Max(1, t.Total);
            _pb.Value = Math.Min(t.Done, _pb.Maximum);
            _lblStatus.Text = $"Измерено точек: {t.Done} / {t.Total}";
        });

        Log($"СТАРТ: {alg.Name}; Nmax={p.NMax}" + (alg.TwoDim ? $", Mmax={p.MMax}" : "") +
            $", шаг={p.Step}, запусков={p.Runs}, принудительно={p.Force}");
        try
        {
            var res = await ExperimentRunner.RunAsync(alg, p, _db, progress, _cts.Token);
            if (res.Cancelled)
            {
                Log($"ОТМЕНЕНО. Новых измерений сохранено в кэш: {res.NewMeasurements}.");
                _lblStatus.Text = "Отменено.";
            }
            else
            {
                Log($"ГОТОВО за {res.ElapsedSec:F2} с: точек {res.TotalPoints}, из кэша {res.CachedPoints}, " +
                    $"новых измерений {res.NewMeasurements}, эксперимент #{res.ExperimentId}.");
                _lblStatus.Text = $"Готово за {res.ElapsedSec:F1} с (из кэша точек: {res.CachedPoints}/{res.TotalPoints}).";
                ShowResult(alg, res.Points);
                RefreshHistory();
            }
        }
        catch (Exception ex)
        {
            Log("ОШИБКА: " + ex);
            MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void SetBusy(bool busy)
    {
        _btnRun.Enabled = !busy;
        _btnCancel.Enabled = busy;
        _cbAlg.Enabled = !busy;
        _btnClear.Enabled = !busy;
    }

    private void ShowResult(AlgorithmDef a, IReadOnlyList<DataPoint> pts)
    {
        if (pts.Count == 0) return;
        _shownAlg = a;
        var sel = (ModelItem)_cbModel.SelectedItem;
        var model = sel?.Value ?? a.Model;

        var models = ModelFn.Applicable(a.TwoDim).Concat(new[] { model }).Distinct().ToList();
        var fits = Approximation.FitAll(pts, a.Metric, models);
        var fit = fits.First(f => f.Model == model);

        _gridFit.Rows.Clear();
        for (int i = 0; i < fits.Count; i++)
            _gridFit.Rows.Add(ModelFn.Title(fits[i].Model),
                fits[i].C.ToString("G6", CultureInfo.InvariantCulture),
                fits[i].Mse.ToString("E4", CultureInfo.InvariantCulture),
                i == 0 ? "★" : "",
                fits[i].Model == model ? "●" : "");

        _lblFit.Text = $"{a.Name}\r\nT_approx = {ModelFn.Title(model)};  C = {fit.C:G6};  " +
                       $"MSE = {fit.Mse:E4};  k = {pts.Count} точек";

        if (a.TwoDim)
        {
            PlotBuilder.FillSurface(_surf, a, pts, model, fit);
            _chart.Visible = false; _surf.Visible = true;
        }
        else
        {
            PlotBuilder.FillChart(_chart, a, pts, model, fit);
            _surf.Visible = false; _chart.Visible = true;
        }
        _tabs.SelectedIndex = 0;
    }

    private void OnClearCache(object sender, EventArgs e)
    {
        var a = Current;
        int cnt = _db.CountMeasurements(a.Key);
        if (MessageBox.Show($"Удалить {cnt} сохранённых измерений алгоритма «{a.Name}»?\n(История экспериментов останется.)",
                "Очистка кэша", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        int del = _db.ClearCache(a.Key);
        Log($"Кэш алгоритма {a.Key} очищен: удалено {del} записей.");
    }

    private void OnExportPng(object sender, EventArgs e)
    {
        if (_shownAlg == null) { MessageBox.Show("Сначала проведите эксперимент или откройте его из истории."); return; }
        using var dlg = new SaveFileDialog { Filter = "PNG|*.png", FileName = $"plot_{_shownAlg.Key}.png" };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        if (_shownAlg.TwoDim) _surf.SavePng(dlg.FileName); else _chart.SavePng(dlg.FileName);
        Log("График сохранён: " + dlg.FileName);
    }

    private void OnReport(object sender, EventArgs e)
    {
        var all = _db.ListExperiments();
        var chosen = _lvHist.CheckedItems.Cast<ListViewItem>().Select(i => (ExperimentInfo)i.Tag).ToList();
        if (chosen.Count == 0)   // ничего не отмечено — берём последний эксперимент каждого алгоритма
            chosen = all.GroupBy(x => x.Algorithm).Select(g => g.First()).ToList();
        if (chosen.Count == 0) { MessageBox.Show("В истории нет экспериментов."); return; }

        using var dlg = new FolderBrowserDialog { Description = "Папка для отчёта (report.md + PNG)" };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        string md = ReportGenerator.Generate(_db, chosen.OrderBy(c => c.Algorithm), dlg.SelectedPath);
        Log("Отчёт создан: " + md);
        try { Process.Start(new ProcessStartInfo("explorer.exe", $"\"{dlg.SelectedPath}\"") { UseShellExecute = true }); } catch { }
    }

    // ===================== история =====================

    private void RefreshHistory()
    {
        _lvHist.BeginUpdate();
        _lvHist.Items.Clear();
        foreach (var e in _db.ListExperiments())
        {
            string name = AlgorithmRegistry.All.FirstOrDefault(a => a.Key == e.Algorithm)?.Name ?? e.Algorithm;
            var it = new ListViewItem(new[]
            {
                e.Id.ToString(), name, e.CreatedAt.ToString("yyyy-MM-dd HH:mm"), e.NMax.ToString(),
                e.MMax.ToString(), e.Step.ToString(), e.Runs.ToString(), $"{e.CachedPoints}/{e.TotalPoints}", e.Forced ? "да" : "нет"
            }) { Tag = e };
            _lvHist.Items.Add(it);
        }
        _lvHist.EndUpdate();
        CompareSelected();
    }

    private void OnShowSelected(object sender, EventArgs e)
    {
        if (_lvHist.SelectedItems.Count == 0) return;
        var info = (ExperimentInfo)_lvHist.SelectedItems[0].Tag;
        var alg = AlgorithmRegistry.ByKey(info.Algorithm);
        _cbAlg.SelectedItem = alg;
        ShowResult(alg, _db.LoadExperimentPoints(info.Id));
    }

    private void OnDeleteChecked(object sender, EventArgs e)
    {
        var items = _lvHist.CheckedItems.Cast<ListViewItem>().ToList();
        if (items.Count == 0) return;
        if (MessageBox.Show($"Удалить экспериментов: {items.Count}?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        foreach (var it in items) _db.DeleteExperiment(((ExperimentInfo)it.Tag).Id);
        RefreshHistory();
    }

    /// <summary>Накладывает на один график все отмеченные эксперименты из истории.</summary>
    private void CompareSelected()
    {
        _hist.Series.Clear();
        int ci = 0;
        bool anyTime = false, anySteps = false;
        foreach (ListViewItem it in _lvHist.CheckedItems)
        {
            var e = (ExperimentInfo)it.Tag;
            var alg = AlgorithmRegistry.All.FirstOrDefault(a => a.Key == e.Algorithm);
            if (alg == null) continue;
            var pts = _db.LoadExperimentPoints(e.Id);
            if (pts.Count == 0) continue;

            string suffix = "";
            if (alg.TwoDim)   // для 3D-экспериментов на 2D-графике берём срез при максимальном m
            {
                int mm = pts.Max(p => p.M);
                pts = pts.Where(p => p.M == mm).ToList();
                suffix = $" (срез m={mm})";
            }
            var ys = pts.Select(p => p.Value(alg.Metric)).ToList();
            double k = _chkNorm.Checked ? ys.Max() : 1;
            if (k <= 0) k = 1;

            var s = new ChartSeries
            {
                Name = $"#{e.Id} {alg.Name}{suffix}",
                Color = Palette[ci++ % Palette.Length],
                Markers = pts.Count < 60,
                Width = 2f
            };
            foreach (var p in pts) s.Pts.Add((p.N, p.Value(alg.Metric) / k));
            _hist.Series.Add(s);
            if (alg.Metric == Metric.Time) anyTime = true; else anySteps = true;
        }

        _hist.Title = _hist.Series.Count == 0 ? "Отметьте эксперименты в списке для сравнения" : "Сравнение экспериментов из истории";
        _hist.XLabel = "Размерность входа n";
        _hist.YLabel = _chkNorm.Checked ? "Значение / максимум (безразмерное)"
            : anyTime && anySteps ? "Время, с / число шагов"
            : anySteps ? "Количество шагов" : "Время, с";
        _hist.LogY = _chkLog.Checked;
        _hist.Invalidate();
    }

    private void Log(string msg) => _txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}\r\n");
}
