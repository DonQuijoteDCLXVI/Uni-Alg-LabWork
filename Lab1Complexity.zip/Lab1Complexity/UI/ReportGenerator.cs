using System.Text;
using Lab1.Algorithms;
using Lab1.Core;
using Lab1.Data;

namespace Lab1.UI;

/// <summary>
/// Генерирует Markdown-отчёт со строгой структурой блока 1.1–1.6 для каждого исследованного алгоритма
/// и сохраняет PNG-графики. Результат можно перевести в PDF/DOCX (pandoc) и оформить по ГОСТ.
/// </summary>
public static class ReportGenerator
{
    public static string Generate(Database db, IEnumerable<ExperimentInfo> experiments, string dir)
    {
        Directory.CreateDirectory(dir);
        var sb = new StringBuilder();
        sb.AppendLine("# Результаты исследования алгоритмов");
        sb.AppendLine();
        sb.AppendLine($"_Сгенерировано автоматически: {DateTime.Now:yyyy-MM-dd HH:mm}_");
        sb.AppendLine();
        sb.AppendLine("> Разделы «Архитектура», «Работа приложения» и «Выводы» заполняются автором отчёта (материал — в README.md).");
        sb.AppendLine();

        int idx = 0;
        foreach (var e in experiments)
        {
            var a = AlgorithmRegistry.ByKey(e.Algorithm);
            var pts = db.LoadExperimentPoints(e.Id);
            if (pts.Count == 0) continue;
            idx++;

            var fits = Approximation.FitAll(pts, a.Metric, ModelFn.Applicable(a.TwoDim));
            var fit = fits.First(f => f.Model == a.Model);
            string png = $"plot_{idx:00}_{a.Key}.png";
            string path = Path.Combine(dir, png);

            if (a.TwoDim)
            {
                using var s = new Surface3DControl();
                PlotBuilder.FillSurface(s, a, pts, a.Model, fit);
                s.SavePng(path);
            }
            else
            {
                using var c = new ChartControl();
                PlotBuilder.FillChart(c, a, pts, a.Model, fit);
                c.SavePng(path);
            }

            sb.AppendLine($"## {idx}. {a.Name}");
            sb.AppendLine();
            sb.AppendLine($"**1.1. Название:** {a.Name}");
            sb.AppendLine();
            sb.AppendLine($"**1.2. Описание:** {a.Description}");
            sb.AppendLine();
            sb.AppendLine($"**1.3. Практическое применение:** {a.Application}");
            sb.AppendLine();
            sb.AppendLine("**1.4. Графики эксперимента:**");
            sb.AppendLine();
            sb.AppendLine($"Параметры: N_max = {e.NMax}" + (a.TwoDim ? $", M_max = {e.MMax}" : "") +
                          $", шаг = {e.Step}, запусков на точку = {e.Runs}, эксперимент #{e.Id} от {e.CreatedAt:yyyy-MM-dd HH:mm}.");
            sb.AppendLine();
            sb.AppendLine($"![График зависимости {(a.Metric == Metric.Time ? "времени" : "шагов")} от n для {a.Name}]({png})");
            sb.AppendLine();
            sb.AppendLine($"Аппроксимация {ModelFn.Title(a.Model)}: **C = {fit.C:G6}**, **MSE = {fit.Mse:E4}** (k = {pts.Count} точек).");
            sb.AppendLine();
            sb.AppendLine("| Модель | C | MSE |");
            sb.AppendLine("|---|---|---|");
            foreach (var f in fits)
                sb.AppendLine($"| {ModelFn.Title(f.Model)}{(f.Model == a.Model ? " (теория)" : "")} | {f.C:G6} | {f.Mse:E4} |");
            sb.AppendLine();
            sb.AppendLine($"**1.5. Справочное O-большое:** {a.BigO}");
            sb.AppendLine();
            sb.AppendLine($"**1.6. Код алгоритма:** см. `{a.CodeRef}`");
            sb.AppendLine();
            sb.AppendLine("---");
            sb.AppendLine();
        }

        string md = Path.Combine(dir, "report.md");
        File.WriteAllText(md, sb.ToString(), new UTF8Encoding(true));
        return md;
    }
}
