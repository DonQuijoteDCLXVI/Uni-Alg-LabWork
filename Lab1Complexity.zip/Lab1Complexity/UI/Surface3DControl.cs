using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;

namespace Lab1.UI;

/// <summary>
/// 3D-каркас: время (ось Z) как функция n (ось X) и m (ось Y).
/// Синяя сетка — эмпирика, оранжевая — аппроксимация C·f(n,m). Мышь: вращение, колесо: масштаб.
/// </summary>
public sealed class Surface3DControl : Control
{
    private double[] _xs = Array.Empty<double>(), _ys = Array.Empty<double>();
    private double[,] _emp, _app;
    private string _xl = "n", _yl = "m", _zl = "", _title = "";
    private double _yaw = -0.8, _pitch = 0.55, _zoom = 1.0;
    private Point _last;
    private bool _drag;

    public Surface3DControl()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.White;
    }

    public void SetData(double[] xs, double[] ys, double[,] emp, double[,] app, string xl, string yl, string zl, string title)
    {
        _xs = xs; _ys = ys; _emp = emp; _app = app; _xl = xl; _yl = yl; _zl = zl; _title = title;
        Invalidate();
    }

    protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); Focus(); }
    protected override void OnMouseDown(MouseEventArgs e) { base.OnMouseDown(e); _drag = true; _last = e.Location; }
    protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); _drag = false; }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (!_drag) return;
        _yaw += (e.X - _last.X) * 0.01;
        _pitch = Math.Clamp(_pitch + (e.Y - _last.Y) * 0.01, -1.5, 1.5);
        _last = e.Location;
        Invalidate();
    }
    protected override void OnMouseWheel(MouseEventArgs e)
    {
        base.OnMouseWheel(e);
        _zoom = Math.Clamp(_zoom * (e.Delta > 0 ? 1.1 : 0.9), 0.3, 4);
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Render(e.Graphics, ClientRectangle);
    }

    public void SavePng(string path, int w = 1200, int h = 800)
    {
        using var bmp = new Bitmap(w, h);
        using var g = Graphics.FromImage(bmp);
        Render(g, new Rectangle(0, 0, w, h));
        bmp.Save(path, ImageFormat.Png);
    }

    private PointF P(double x, double y, double z, Rectangle r)
    {
        double cy = Math.Cos(_yaw), sy = Math.Sin(_yaw), cp = Math.Cos(_pitch), sp = Math.Sin(_pitch);
        double xr = x * cy - y * sy;
        double yr = x * sy + y * cy;
        double scale = Math.Min(r.Width, r.Height) * 0.55 * _zoom;
        double screenX = xr;
        double screenY = z * cp + yr * sp;
        return new PointF((float)(r.Left + r.Width / 2.0 + screenX * scale),
                          (float)(r.Top + r.Height / 2.0 + 10 - screenY * scale));
    }

    public void Render(Graphics g, Rectangle r)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.Clear(Color.White);
        using var font = new Font("Segoe UI", 9f);
        using var titleFont = new Font("Segoe UI", 11f, FontStyle.Bold);
        if (_emp == null || _xs.Length == 0 || _ys.Length == 0)
        {
            g.DrawString("Нет данных для отображения", font, Brushes.Gray, r.Left + 10, r.Top + 10);
            return;
        }

        double xmin = _xs.Min(), xmax = _xs.Max(), ymin = _ys.Min(), ymax = _ys.Max();
        double zmax = 0;
        foreach (var v in _emp) zmax = Math.Max(zmax, v);
        foreach (var v in _app) zmax = Math.Max(zmax, v);
        if (zmax <= 0) zmax = 1;

        double NX(double v) => xmax > xmin ? (v - xmin) / (xmax - xmin) - 0.5 : 0;
        double NY(double v) => ymax > ymin ? (v - ymin) / (ymax - ymin) - 0.5 : 0;
        double NZ(double v) => v / zmax - 0.5;

        // коробка
        using (var boxPen = new Pen(Color.Silver))
        {
            double[] c = { -0.5, 0.5 };
            foreach (var a in c) foreach (var b in c)
            {
                g.DrawLine(boxPen, P(-0.5, a, b, r), P(0.5, a, b, r));
                g.DrawLine(boxPen, P(a, -0.5, b, r), P(a, 0.5, b, r));
                g.DrawLine(boxPen, P(a, b, -0.5, r), P(a, b, 0.5, r));
            }
        }
        using (var axPen = new Pen(Color.Black, 1.5f))
        {
            g.DrawLine(axPen, P(-0.5, -0.5, -0.5, r), P(0.5, -0.5, -0.5, r));
            g.DrawLine(axPen, P(-0.5, -0.5, -0.5, r), P(-0.5, 0.5, -0.5, r));
            g.DrawLine(axPen, P(-0.5, -0.5, -0.5, r), P(-0.5, -0.5, 0.5, r));
        }
        g.DrawString($"{_xl} = {Fmt(xmax)}", font, Brushes.Black, P(0.5, -0.5, -0.5, r));
        g.DrawString($"{_yl} = {Fmt(ymax)}", font, Brushes.Black, P(-0.5, 0.5, -0.5, r));
        g.DrawString($"{_zl} = {Fmt(zmax)}", font, Brushes.Black, P(-0.5, -0.5, 0.5, r));

        // аппроксимация (оранжевая) и эмпирика (синяя)
        DrawMesh(g, r, _app, NX, NY, NZ, Color.FromArgb(230, 255, 140, 0), 1.6f, false);
        DrawMesh(g, r, _emp, NX, NY, NZ, Color.FromArgb(230, 30, 100, 200), 1.2f, true);

        if (!string.IsNullOrEmpty(_title))
            g.DrawString(_title, titleFont, Brushes.Black,
                new RectangleF(r.Left, r.Top + 6, r.Width, 24),
                new StringFormat { Alignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter });

        // легенда
        using (var p1 = new Pen(Color.FromArgb(30, 100, 200), 3))
        using (var p2 = new Pen(Color.FromArgb(255, 140, 0), 3))
        {
            g.DrawLine(p1, r.Left + 10, r.Top + 40, r.Left + 32, r.Top + 40);
            g.DrawString("Эмпирические данные", font, Brushes.Black, r.Left + 36, r.Top + 31);
            g.DrawLine(p2, r.Left + 10, r.Top + 58, r.Left + 32, r.Top + 58);
            g.DrawString("Аппроксимация C·f(n,m)", font, Brushes.Black, r.Left + 36, r.Top + 49);
            g.DrawString("ЛКМ + движение — вращение, колесо — масштаб", font, Brushes.Gray, r.Left + 10, r.Bottom - 22);
        }
    }

    private void DrawMesh(Graphics g, Rectangle r, double[,] z, Func<double, double> nx, Func<double, double> ny,
        Func<double, double> nz, Color color, float width, bool dots)
    {
        using var pen = new Pen(color, width);
        using var br = new SolidBrush(color);
        int nxCount = _xs.Length, nyCount = _ys.Length;
        for (int i = 0; i < nxCount; i++)
        {
            var line = new List<PointF>();
            for (int j = 0; j < nyCount; j++) line.Add(P(nx(_xs[i]), ny(_ys[j]), nz(z[i, j]), r));
            if (line.Count > 1) g.DrawLines(pen, line.ToArray());
        }
        for (int j = 0; j < nyCount; j++)
        {
            var line = new List<PointF>();
            for (int i = 0; i < nxCount; i++) line.Add(P(nx(_xs[i]), ny(_ys[j]), nz(z[i, j]), r));
            if (line.Count > 1) g.DrawLines(pen, line.ToArray());
        }
        if (dots)
            for (int i = 0; i < nxCount; i++)
                for (int j = 0; j < nyCount; j++)
                {
                    var p = P(nx(_xs[i]), ny(_ys[j]), nz(z[i, j]), r);
                    g.FillEllipse(br, p.X - 2, p.Y - 2, 4, 4);
                }
    }

    private static string Fmt(double v)
    {
        if (v == 0) return "0";
        double a = Math.Abs(v);
        if (a >= 1e5 || a < 1e-3) return v.ToString("0.##E+0", CultureInfo.InvariantCulture);
        return v.ToString("G5", CultureInfo.InvariantCulture);
    }
}
