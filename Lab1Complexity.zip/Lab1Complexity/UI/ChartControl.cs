using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;

namespace Lab1.UI;

public sealed class ChartSeries
{
    public string Name { get; set; } = "";
    public Color Color { get; set; } = Color.Black;
    public bool Line { get; set; } = true;
    public bool Markers { get; set; }
    public float Width { get; set; } = 2f;
    public List<(double X, double Y)> Pts { get; } = new();
}

/// <summary>Простой 2D-график (линии + маркеры, легенда, сетка, опциональная логарифмическая шкала Y).</summary>
public sealed class ChartControl : Control
{
    public string Title { get; set; } = "";
    public string XLabel { get; set; } = "n";
    public string YLabel { get; set; } = "";
    public List<ChartSeries> Series { get; } = new();

    private bool _logY;
    public bool LogY { get => _logY; set { _logY = value; Invalidate(); } }

    public ChartControl()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.White;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Render(e.Graphics, ClientRectangle);
    }

    public void SavePng(string path, int w = 1200, int h = 700)
    {
        using var bmp = new Bitmap(w, h);
        using var g = Graphics.FromImage(bmp);
        Render(g, new Rectangle(0, 0, w, h));
        bmp.Save(path, ImageFormat.Png);
    }

    public void Render(Graphics g, Rectangle r)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.Clear(Color.White);
        using var font = new Font("Segoe UI", 9f);
        using var titleFont = new Font("Segoe UI", 11f, FontStyle.Bold);
        using var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter };

        var all = Series.SelectMany(s => s.Pts)
            .Where(p => double.IsFinite(p.X) && double.IsFinite(p.Y) && (!LogY || p.Y > 0)).ToList();
        if (all.Count == 0)
        {
            g.DrawString("Нет данных для отображения", font, Brushes.Gray, r.Left + 10, r.Top + 10);
            return;
        }

        int left = 84, right = 20, top = string.IsNullOrEmpty(Title) ? 14 : 34, bottom = 52;
        var plot = new Rectangle(r.Left + left, r.Top + top, r.Width - left - right, r.Height - top - bottom);
        if (plot.Width < 60 || plot.Height < 60) return;

        // ---- шкалы ----
        double xmax = all.Max(p => p.X);
        var (x0, x1, xs) = NiceScale(0, xmax);

        Func<double, double> ty = LogY ? (v => Math.Log10(v)) : (v => v);
        double y0, y1, ys;
        if (!LogY)
        {
            (y0, y1, ys) = NiceScale(Math.Min(0, all.Min(p => p.Y)), all.Max(p => p.Y));
        }
        else
        {
            y0 = Math.Floor(Math.Log10(all.Min(p => p.Y)));
            y1 = Math.Ceiling(Math.Log10(all.Max(p => p.Y)));
            if (y1 <= y0) y1 = y0 + 1;
            ys = Math.Max(1, Math.Round((y1 - y0) / 8));
        }

        float MX(double x) => plot.Left + (float)((x - x0) / (x1 - x0) * plot.Width);
        float MY(double y) => plot.Bottom - (float)((ty(y) - y0) / (y1 - y0) * plot.Height);

        // ---- сетка и подписи ----
        using var gridPen = new Pen(Color.FromArgb(225, 225, 225));
        int nx = (int)Math.Round((x1 - x0) / xs);
        for (int i = 0; i <= nx; i++)
        {
            double v = x0 + i * xs;
            float px = MX(v);
            g.DrawLine(gridPen, px, plot.Top, px, plot.Bottom);
            g.DrawString(Fmt(v), font, Brushes.Black, new RectangleF(px - 40, plot.Bottom + 3, 80, 18), center);
        }
        int ny = (int)Math.Round((y1 - y0) / ys);
        for (int i = 0; i <= ny; i++)
        {
            double t = y0 + i * ys;
            float py = plot.Bottom - (float)((t - y0) / (y1 - y0) * plot.Height);
            g.DrawLine(gridPen, plot.Left, py, plot.Right, py);
            string lab = LogY ? Fmt(Math.Pow(10, t)) : Fmt(t);
            g.DrawString(lab, font, Brushes.Black, new RectangleF(r.Left + 2, py - 9, left - 8, 18),
                new StringFormat { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Center });
        }
        g.DrawRectangle(Pens.Black, plot);

        if (!string.IsNullOrEmpty(Title))
            g.DrawString(Title, titleFont, Brushes.Black, new RectangleF(r.Left, r.Top + 6, r.Width, 24), center);
        g.DrawString(XLabel, font, Brushes.Black, new RectangleF(plot.Left, plot.Bottom + 24, plot.Width, 20), center);
        var st = g.Save();
        g.TranslateTransform(r.Left + 14, plot.Top + plot.Height / 2f);
        g.RotateTransform(-90);
        g.DrawString(YLabel, font, Brushes.Black, new RectangleF(-plot.Height / 2f, -10, plot.Height, 20), center);
        g.Restore(st);

        // ---- серии ----
        g.SetClip(plot);
        foreach (var s in Series)
        {
            var pts = s.Pts.Where(p => double.IsFinite(p.X) && double.IsFinite(p.Y) && (!LogY || p.Y > 0))
                .OrderBy(p => p.X).Select(p => new PointF(MX(p.X), MY(p.Y))).ToArray();
            if (pts.Length == 0) continue;
            using var pen = new Pen(s.Color, s.Width) { LineJoin = LineJoin.Round };
            if (s.Line && pts.Length > 1) g.DrawLines(pen, pts);
            if (s.Markers || pts.Length == 1)
                using (var br = new SolidBrush(s.Color))
                    foreach (var p in pts) g.FillEllipse(br, p.X - 2.5f, p.Y - 2.5f, 5, 5);
        }
        g.ResetClip();

        // ---- легенда ----
        var legend = Series.Where(s => s.Pts.Count > 0 && !string.IsNullOrEmpty(s.Name)).ToList();
        if (legend.Count > 0)
        {
            float w = legend.Max(s => g.MeasureString(s.Name, font).Width) + 40;
            float h = legend.Count * 18 + 8;
            var box = new RectangleF(plot.Left + 8, plot.Top + 8, Math.Min(w, plot.Width - 16), h);
            using (var bg = new SolidBrush(Color.FromArgb(225, 255, 255, 255))) g.FillRectangle(bg, box);
            g.DrawRectangle(Pens.Silver, box.X, box.Y, box.Width, box.Height);
            for (int i = 0; i < legend.Count; i++)
            {
                float yy = box.Y + 4 + i * 18;
                using var pen = new Pen(legend[i].Color, 3);
                g.DrawLine(pen, box.X + 6, yy + 9, box.X + 28, yy + 9);
                g.DrawString(legend[i].Name, font, Brushes.Black, box.X + 32, yy);
            }
        }
    }

    private static string Fmt(double v)
    {
        if (v == 0) return "0";
        double a = Math.Abs(v);
        if (a >= 1e5 || a < 1e-3) return v.ToString("0.##E+0", CultureInfo.InvariantCulture);
        return v.ToString("G5", CultureInfo.InvariantCulture);
    }

    private static (double min, double max, double step) NiceScale(double min, double max, int ticks = 6)
    {
        if (max <= min) max = min + 1;
        double range = Nice(max - min, false);
        double step = Nice(range / (ticks - 1), true);
        return (Math.Floor(min / step) * step, Math.Ceiling(max / step) * step, step);
    }

    private static double Nice(double x, bool round)
    {
        double exp = Math.Floor(Math.Log10(x));
        double f = x / Math.Pow(10, exp);
        double nf = round ? (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10)
                          : (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10);
        return nf * Math.Pow(10, exp);
    }
}
